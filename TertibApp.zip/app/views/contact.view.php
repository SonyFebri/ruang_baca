<?php ?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Learn | Contact</title>
	<link rel="stylesheet" href="">
</head>

<body>
	<h1>Contact us page</h1>
	<?php require 'partials/nav.view.php'; ?>
</body>

</html>