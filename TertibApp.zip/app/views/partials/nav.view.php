<nav>
	<ul>
		<li><a href="<?php echo App::get('root_uri'); ?>" title="Home">Home</a></li>
		<li><a href="about" title="About us">About us</a></li>
		<li><a href="contact" title="Your feedback is important to us">Contact</a></li>
		<li><a href="users" title="All Users">View Users</a></li>
	</ul>
</nav>